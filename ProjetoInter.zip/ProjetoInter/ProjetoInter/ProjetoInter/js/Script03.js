document.getElementById("credit").addEventListener("click", function(){
    document.getElementById("caixa2").innerHTML = `                
    <p id="infotext">Informações</p>
    <p class="textinput">Número do Cartão</p>
    <input type="text" id="txtnumerocartao" class="inputpag">
    <p class="textinput" id="textdata">Data de Validade</p>
    <p class="textinput" id="textcvv">CVC/CVV</p>
    <input type="text" id="txtvalidade" class="inputpag">
    <input type="text" id="txtcvv" class="inputpag">
    <p class="textinput">Nome no cartão</p>
    <input type="text" id="txtcartaonome" class="inputpag">
    <a href="#" id="cvvquest">O que é CVV?</a>
    <a href="sessoes.html" id="btnpronto">Pronto</a>`
})



document.getElementById("pix").addEventListener("click", function(){
    document.getElementById("caixa2").innerHTML = `<h2>Escaneie Aqui</h2><br><a href="sessoes.html"><img src="img/qrcode.png" id="qrcode"></a>`
})
document.getElementById("paypal").addEventListener("click", function(){
    document.getElementById("caixa2").innerHTML = `<h2>Escaneie Aqui</h2><br><a href="sessoes.html"><img src="img/qrcode2.png" id="qrcode"></a>`
})
let filme = localStorage.getItem('filmeescolha');
let filmelista = localStorage.getItem("filmelista");
if(filme == '1'){
     localStorage.filmelista += '<img src="img/Oppenheimer.png" id="filmecomprado">'
}else if(filme == '2'){
    localStorage.filmelista += '<img src="img/FaleComigo.png" id="filmecomprado">'
}else if(filme == '3'){
    localStorage.filmelista += '<img src="img/MegaTubarao.png" id="filmecomprado">'
}else if(filme == '4'){
    localStorage.filmelista += '<img src="img/Elementos.png" id="filmecomprado">'
}else if(filme == '5'){
    localStorage.filmelista += '<img src="img/BesouroAzul.png" id="filmecomprado">'
}else if(filme == '6'){
    localStorage.filmelista += '<img src="img/Corredor.png" id="filmecomprado">'
}else if(filme == '7'){
    localStorage.filmelista += '<img src="img/Pooh.png" id="filmecomprado">'
}else if(filme == '8'){
    localStorage.filmelista += '<img src="img/Barbie.png" id="filmecomprado">'
}else if(filme == '9'){
    localStorage.filmelista += '<img src="img/guardians.png" id="filmecomprado">'
}else if(filme == '10'){
    localStorage.filmelista += '<img src="img/spiderman.png" id="filmecomprado">'
}
