let filme = localStorage.getItem('filmeescolha');

if(filme == '1'){
    document.getElementById("fotofilme").src = 'img/Oppenheimer.png';
}else if(filme == '2'){
    document.getElementById("fotofilme").src = 'img/FaleComigo.png';
}else if(filme == '3'){
    document.getElementById("fotofilme").src = 'img/MegaTubarao.png';
}else if(filme == '4'){
    document.getElementById("fotofilme").src = 'img/Elementos.png';
}else if(filme == '5'){
    document.getElementById("fotofilme").src = 'img/BesouroAzul.png';
}else if(filme == '6'){
    document.getElementById("fotofilme").src = 'img/Corredor.png';
}else if(filme == '7'){
    document.getElementById("fotofilme").src = 'img/Pooh.png';
}else if(filme == '8'){
    document.getElementById("fotofilme").src = 'img/Barbie.png';
}else if(filme == '9'){
    document.getElementById("fotofilme").src = 'img/guardians.png';
}else if(filme == '10'){
    document.getElementById("fotofilme").src = 'img/spiderman.png';
}
