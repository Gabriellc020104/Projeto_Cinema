# Projeto_Cinema
 um site de cinema interativo, construído com JavaScript, HTML5 e CSS3! FilmaFlix oferece uma experiência imersiva e personalizada para navegantes do universo do cinema.
