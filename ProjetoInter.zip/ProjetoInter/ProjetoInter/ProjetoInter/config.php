<?php
    if(isset($_POST["cadastrar"])){
        $nome = $_POST['nome']; 
        $cpf = $_POST['cpf']; 
        $email = $_POST['email']; 
        $password = $_POST['senha'];
        $password_repeat = $_POST['confirmar_senha']; 
    }
    

    if($password != $password_repeat){
        die("Senha invalida");
    }

    $host = "localhost";
    $banco = "inter";
    $user  ="root";
    $senha = "";

    $con = mysqli_connect( $host, $user, $senha,$banco);

    if(!$con){
        die("conexao falhou" . mysqli_connect_erro());
    }

    $sql = "INSERT INTO usuarios(nome,cpf, email, senha) VALUES ('$nome','$cpf', '$email', '$password')";

    $rs = mysqli_query($con,$sql);

    if($rs){
        header("Location: sessao.html");
        echo "voce foi cadastrado";
    }


?>
