<?php
  $user  ="root";
  $senha = "";
  $banco = "inter";
  $host = "localhost";
  
  

  $mysqli = new mysqli($host,$user,$senha, $banco);

  if($mysqli->error){
    die("falha ao conectar: ". $mysqli->error);
  }

?>