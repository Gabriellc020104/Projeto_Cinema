document.getElementById("btnopen").addEventListener("click", function(){
    let fotofilme = 'filmeescolha';
    localStorage.setItem(fotofilme, 1);
});
document.getElementById("btnfale").addEventListener("click", function(){
    let fotofilme = 'filmeescolha';
    localStorage.setItem(fotofilme, 2);
});
document.getElementById("btnmega").addEventListener("click", function(){
    let fotofilme = 'filmeescolha';
    localStorage.setItem(fotofilme, 3);
});
document.getElementById("btnelementos").addEventListener("click", function(){
    let fotofilme = 'filmeescolha';
    localStorage.setItem(fotofilme, 4);
});
document.getElementById("btnazul").addEventListener("click", function(){
    let fotofilme = 'filmeescolha';
    localStorage.setItem(fotofilme, 5);
});
document.getElementById("btncorredor").addEventListener("click", function(){
    let fotofilme = 'filmeescolha';
    localStorage.setItem(fotofilme, 6);
});
document.getElementById("btnpooh").addEventListener("click", function(){
    let fotofilme = 'filmeescolha';
    localStorage.setItem(fotofilme, 7);
});
document.getElementById("btnbarbie").addEventListener("click", function(){
    let fotofilme = 'filmeescolha';
    localStorage.setItem(fotofilme, 8);
});
document.getElementById("btnguar").addEventListener("click", function(){
    let fotofilme = 'filmeescolha';
    localStorage.setItem(fotofilme, 9);
});
document.getElementById("btnspi").addEventListener("click", function(){
    let fotofilme = 'filmeescolha';
    localStorage.setItem(fotofilme, 10);
});

let contador = 1;
document.getElementById("prebtn").addEventListener("click", function(){
    if(contador == 1){
        contador = 4
    }else{
        contador --
    }

    if(contador == 4){document.getElementById("fotomeio").src = `img/filme${contador}.png`}
    else if(contador == 3){document.getElementById("fotomeio").src = `img/filme${contador}.png`}
    else if(contador == 2){document.getElementById("fotomeio").src = `img/filme${contador}.png`}
    else if(contador == 1){document.getElementById("fotomeio").src = `img/filme${contador}.png`}
});
document.getElementById("posbtn").addEventListener("click", function(){
    if(contador == 4){
        contador = 1
    }else{
        contador ++
    }

    if(contador == 4){document.getElementById("fotomeio").src = `img/filme${contador}.png`}
    else if(contador == 3){document.getElementById("fotomeio").src = `img/filme${contador}.png`}
    else if(contador == 2){document.getElementById("fotomeio").src = `img/filme${contador}.png`}
    else if(contador == 1){document.getElementById("fotomeio").src = `img/filme${contador}.png`}
});