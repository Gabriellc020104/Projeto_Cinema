<?php
include('conexao.php');

if(isset($_POST['email']) || isset($_POST['senha'])){
        
    if(strlen($_POST['email']) == 0) {
        echo"preencha seu email";
    } else if(strlen($_POST['senha']) == 0){
        echo"preencha sua senha";
    } else{
        $email = $mysqli->real_escape_string($_POST['email']);
        $senha = $mysqli->real_escape_string($_POST['senha']);

        $sql_code = "SELECT * FROM usuarios WHERE email = '$email' AND senha ='$senha'";
        $sql_query = $mysqli->query($sql_code) or die("Fala na execucao: " . $mysqli->error );  

        $quantidade = $sql_query->num_rows;
        
        if($quantidade == 1){

            $usuario = $sql_query->fetch_assoc();

            if(isset($_SESSION)){

                session_start();

            }
            $_SESSION['nome'] = $usuario['nome'];

            header("Location: ativo.php");

        }else{
            echo"fala ao logar! Senha ou email incorretos";

        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div id="container">
        <h1>Preencha com os seus dados</h1>  
        <h1 id="h1login">Login</h1>        
                <div id="login">
                <form action="" method="POST">
                    <form action="login.php" method="POST">
                    <input type="email" id="email2" name="email" placeholder="E-mail:" onfocus="hidePlaceholder(this)" required>
                    <input type="password" id="senha2" name="senha" placeholder="Senha" onfocus="hidePlaceholder(this)" required>
                    <button id="btnlogin">Entrar</button>
                    <input type="checkbox" id="connect" name="conectar" value="termos"><label>Continuar conectado</label>
                </form>
                <a href='cadastro.html'><button id="btnsenha" class="buttonesq">Nao tenho conta</button></a>
                </div>   
                <a href="index.html" id="volta">Voltar</a>     
    </div>
</body>
</html>