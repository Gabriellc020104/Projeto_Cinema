<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/sessao.css">
    <title>Document</title>
</head>
<body>
    <h1>Voce foi conectado.</h1>

    <p>
        <a href="index2.html"> Escolha seu filme</a>
    </p>
    
</body>
</html>